<!DOCTYPE html>
<html>
<body>

<h2>Clubs List</h2>

<?php
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "clubs";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// SQL query to fetch club data
$sql = "SELECT clubName, email, room, meetingTime, advisor FROM Clubs";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row as table rows
    echo "<table>";
    while($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . htmlspecialchars($row["clubName"]) . "</td>
                <td>" . htmlspecialchars($row["email"]) . "</td>
                <td>" . htmlspecialchars($row["room"]) . "</td>
                <td>" . htmlspecialchars($row["meetingTime"]) . "</td>
                <td>" . htmlspecialchars($row["advisor"]) . "</td>
              </tr>";
    }
    echo "</table>";
} else {
    echo "<tr><td colspan='5'>No club data available</td></tr>";
}

$conn->close();
?>


<br><br>
<a href="calender.html">Back to main menu</a>

</body>
</html>