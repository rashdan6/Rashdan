-- Create the Clubs table with clubID as the primary key
CREATE TABLE Clubs (
    clubID VARCHAR(4) PRIMARY KEY,
    clubName VARCHAR(30),
    email VARCHAR(50),
    room VARCHAR(10),
    meetingTime VARCHAR(50),
    advisor VARCHAR(50)
);

-- Insert statements
INSERT INTO Clubs (clubID, clubName, email, room, meetingTime, advisor) VALUES
('101', 'Accounting Club', 'accountingclub@gmail.com', 'F208', 'Wednesdays 2pm-4pm', 'Oliver Bennett'),
('202', 'Acentos Latinos Club', 'cacentoslatinos@gmail.com', 'M317', 'Wednesdays 2pm-4pm', 'Emma Fostero'),
('303', 'Arabic Cultural Club', 'ArabicCulturalClub@gmail.com', 'M314', 'Wednesdays 2pm-4pm', 'James Monroe'),
('404', 'Digital Club', 'arthistory@gmail.com', 'F1010', 'Wednesdays 2pm-4pm', 'Ava Collins'),
('505', 'Latinos in STEM', 'latinos.in.stem@gmail.com', 'M380', 'Wednesdays 2pm-4pm', 'Henry Mitchell'),
('606', 'K-Pop Club', 'K-PopClub@gmail.com', 'F405', 'Wednesdays 2pm-4pm', 'William Lee'),
('707', 'Photo Club', 'digital@gmail.com', 'F1104', 'Wednesdays 2pm-4pm', 'Evelyn Bennett'),
('808', 'Model United Nations', 'mun@gmail.com', 'N-455', 'Wednesdays 2pm-4pm', 'Alexander Simmons'),
('909', 'Cheerleading Club/Pantherettes', 'hearleadingclub@gmail.com', 'N-450', 'Wednesdays 2pm-4pm', 'Benjamin Parker'),
('1010', 'Bangladesh Students Association', 'bsa2324@gmail.com', 'N-468', 'Wednesdays 2pm-4pm', 'Daniel Carter'),
('1111', 'Marketing Club', 'latinos@gmail.com', 'M380', 'Wednesdays 2pm-4pm', 'Jonathan Ross'),
('1212', 'Fashion Flick Society', 'Creativedirector@gmail.com', 'F503', 'Wednesdays 2pm-4pm', 'Simth Gammef'),
('1313', 'Students for Justice in Palestine', 'sfj@gmal.com', 'M316', 'Wednesdays 2pm-4pm', 'Midnf Odnds'),
('1414', 'Pre-Law Society Club', 'prelawsocitei@gmail.com', 'F607', 'Wednesdays 2pm-4pm', 'Jndi Nodn'),
('1515', 'History Club', 'aclub@gmail.com', 'F1010', 'Wednesdays 2pm-4pm', 'Lucy Simmons'),
('1616', 'English Conversation Club', 'englishconversa@gmail.com', 'M205', 'Wednesdays 2pm-4pm', 'Aria Myers'),
('1717', 'Reading Club', 'dial@gmail.com', 'F1104', 'Wednesdays 2pm-4pm', 'Elijah Rogers'),
('1818', 'Organization of Student Veterans Club', 'latos@gmail.com', 'M380', 'Wednesdays 2pm-4pm', 'Madison Coleman'),
('1919', 'Respiratory Therapy Club', 'ahclub@gmail.com', 'F1010', 'Wednesdays 2pm-4pm', 'Sarah Nosdm'),
('2020', 'Out in Two Club', 'latstem@gmail.com', 'M380', 'Wednesdays 2pm-4pm', 'Janjgn Nod'),
('2121', 'Writer Guild', 'aclub@gmail.com', 'F1010', 'Wednesdays 2pm-4pm', 'Harah Akdn'),
('2222', 'Corporate Engagement Club', 'latino@gmail.com', 'M380', 'Wednesdays 2pm-4pm', 'Jjodsn Dod'),
('2323', 'Music Club', 'alub@gmail.com', 'F1010', 'Wednesdays 2pm-4pm', 'Sarah Maosndm');